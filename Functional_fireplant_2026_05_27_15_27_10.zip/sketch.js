// Variáveis das posições dos animais
let galinhaX = 50;
let galinhaY = 280;

let vacadddX = 50;
let vacaY = 120; // Posição mais alta, já que ela voa

// Variáveis de controle do jogo
let larguraLinhaChegada = 700;
let jogoTerminado = false;
let vencedor = "";

function setup() {
  // Cria o canvas e coloca dentro da tag 'main' do HTML
  let canvas = createCanvas(800, 400);
  canvas.parent('canvas-container');
}

function draw() {
  background('#87CEEB'); // Céu azul
  
  // Desenha o solo/pasto sustentável
  fill('#4CAF50');
  noStroke();
  rect(0, 220, width, 180);
  
  // Desenha a divisão de pistas
  stroke(255);
  strokeWeight(2);
  line(0, 220, width, 220);
  
  // Desenha a Linha de Chegada (Estilizada como horta vertical ou faixa verde)
  fill('#2E7D32');
  rect(larguraLinhaChegada, 0, 20, height);
  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("FIM", larguraLinhaChegada + 10, height / 2);

  if (!jogoTerminado) {
    // Mecânica de movimentação e controle
    // Galinha avança apertando a tecla 'D' (ou 'd')
    if (keyIsPressed && (key === 'd' || key === 'D')) {
      galinhaX += 2;
    }
    // Vaca Voadora avança apertando a Seta para a Direita (RIGHT_ARROW)
    if (keyIsPressed && keyCode === RIGHT_ARROW) {
      vacaX += 2;
    }
    
    // Animação da vaca flutuando levemente no ar (efeito voador usando a função senoidal)
    vacaY = 120 + sin(frameCount * 0.1) * 10;
    
    // Checagem de vitória
    if (galinhaX >= larguraLinhaChegada) {
      jogoTerminado = true;
      vencedor = "Galinha Ecológica!";
    } else if (vacaX >= larguraLinhaChegada) {
      jogoTerminado = true;
      vencedor = "Vaca Voadora Sustentável!";
    }
  }

  // --- DESENHO DOS PERSONAGENS ---
  // Substitua as formas geométricas abaixo por imagens reais carregadas com a função loadImage() se desejar
  
  // Desenho da Vaca Voadora (com pequenas asas mecânicas/energia limpa)
  push();
  translate(vacaX, vacaY);
  // Corpo da vaca
  fill(255);
  ellipse(0, 0, 60, 40);
  fill(0);
  ellipse(-10, -5, 10, 10); // Manchas
  ellipse(15, 5, 12, 12);
  // Cabeça
  fill(230);
  ellipse(30, -10, 25, 25);
  // Asas da vaca voadora (batendo de acordo com o frameCount)
  fill(173, 216, 230);
  push();
  rotate(sin(frameCount * 0.2));
  ellipse(0, -20, 15, 30);
  pop();
  pop();

  // Desenho da Galinha
  push();
  translate(galinhaX, galinhaY);
  // Corpo
  fill(255, 235, 59);
  ellipse(0, 0, 40, 35);
  // Crista
  fill(244, 67, 54);
  ellipse(10, -20, 10, 10);
  // Cabeça
  fill(255, 235, 59);
  ellipse(12, -12, 20, 20);
  // Bico
  fill(255, 152, 0);
  triangle(20, -15, 20, -9, 26, -12);
  pop();

  // --- TELA DE FIM DE JOGO ---
  if (jogoTerminado) {
    fill(0, 0, 0, 150);
    rect(0, 0, width, height);
    
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Vitória da " + vencedor, width / 2, height / 2 - 20);
    textSize(18);
    text("Produção equilibrada gera um futuro forte!", width / 2, height / 2 + 20);
    textSize(14);
    text("Atualize a página para correr novamente.", width / 2, height / 2 + 60);
  }
}